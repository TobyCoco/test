#include <math.h>
#include <stdio.h>

void print_pow(void) {
    printf("%.0f\n", pow(2, 10));
}
