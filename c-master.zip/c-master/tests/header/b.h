char b = 'b';
