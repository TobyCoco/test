char c = 'c';
