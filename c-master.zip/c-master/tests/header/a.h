#include "b.h"
char a = 'a';
