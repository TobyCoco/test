#!../../c
#include <stdio.h>

int main(int argc, char **argv) {
    printf("(%s) (%s) (%s)\n", argv[1], argv[2], argv[3]);

    return 88;
}
