int some_func() {
    return 123;
}
