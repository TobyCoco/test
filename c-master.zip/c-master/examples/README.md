c Examples
==========

```bash
$ ./example_name.c
# OR
$ c example_name.c
```
